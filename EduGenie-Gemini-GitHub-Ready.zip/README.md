# EduGenie Gemini

EduGenie is a FastAPI + Google Gemini learning assistant for explanations, Q&A, quizzes, summaries, and learning paths.

## GitHub-safe project

This repository does **not** include a Python virtual environment, Python cache files, a real `.env` file, or an API key. Keep your secret key only in a local `.env` file.

## Setup

### 1. Clone the repository

```bash
git clone <YOUR_GITHUB_REPOSITORY_URL>
cd EduGenie-Gemini
```

### 2. Create and activate a virtual environment

Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure Gemini

Copy `.env.example` to `.env` and replace `YOUR_GEMINI_API_KEY_HERE` with your own key.

```env
GEMINI_API_KEY=YOUR_GEMINI_API_KEY_HERE
GEMINI_MODEL=gemini-3.8-flash
```

**Never commit `.env` or expose your API key in GitHub.**

### 5. Run

```bash
uvicorn main:app --reload
```

Then open `http://127.0.0.1:8000`.

For port 5000:

```bash
uvicorn main:app --reload --port 5000
```

## Project structure

```text
EduGenie-Gemini/
├── main.py
├── config.py
├── gemini_client.py
├── explanation_module.py
├── learning_path.py
├── qna.py
├── quiz_module.py
├── summary_module.py
├── requirements.txt
├── .env.example
├── .gitignore
├── static/
├── templates/
└── tests/
```

## Gemini availability

The Gemini client includes retry and fallback handling for temporary model availability errors. If a model is unavailable or overloaded, the application can try another configured Flash model.

## License

Add your preferred license before publishing if this project is intended for public distribution.
