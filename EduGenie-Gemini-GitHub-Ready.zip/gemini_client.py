from functools import lru_cache
from typing import Type, TypeVar
import time

from pydantic import BaseModel

from config import get_settings

T = TypeVar("T", bound=BaseModel)

# Current stable Flash models. If one is temporarily overloaded, EduGenie
# can retry and then move to another supported model.
MODEL_FALLBACKS = [
    "gemini-3.8-flash",
    "gemini-3.7-flash",
    "gemini-3.6-flash",
    "gemini-3.5-flash",
    "gemini-3.5-flash-lite",
    "gemini-2.5-flash",
]

MAX_RETRIES_PER_MODEL = 3
RETRY_DELAYS_SECONDS = (1, 2, 4)


@lru_cache(maxsize=1)
def get_client():
    from google import genai

    settings = get_settings()
    api_key = settings.gemini_api_key.strip()

    if not api_key:
        raise RuntimeError(
            "Gemini API key is missing. Add GEMINI_API_KEY to the .env file "
            "in the EduGenie project root."
        )

    return genai.Client(api_key=api_key)


def _candidate_models():
    configured = get_settings().gemini_model.strip()
    result = []
    if configured:
        result.append(configured)
    for model in MODEL_FALLBACKS:
        if model not in result:
            result.append(model)
    return result


def _generation_config(*, system_instruction: str | None = None):
    from google.genai import types

    settings = get_settings()

    # Gemini 3.x recommends thinking_level instead of the older sampling
    # controls such as temperature.
    if settings.gemini_model.strip().startswith("gemini-3"):
        return types.GenerateContentConfig(
            system_instruction=system_instruction,
            max_output_tokens=settings.max_output_tokens,
            thinking_config=types.ThinkingConfig(thinking_level="low"),
        )

    return types.GenerateContentConfig(
        system_instruction=system_instruction,
        temperature=settings.temperature,
        max_output_tokens=settings.max_output_tokens,
    )


def _is_model_not_found(exc: Exception) -> bool:
    message = str(exc).lower()
    return (
        "404" in message
        or "not found" in message
        or "is not supported" in message
    )


def _is_transient_unavailable(exc: Exception) -> bool:
    message = str(exc).lower()
    return any(
        marker in message
        for marker in (
            "503",
            "unavailable",
            "service unavailable",
            "high demand",
            "temporarily unavailable",
            "500 internal",
            "502 bad gateway",
            "504 gateway",
        )
    )


def _call_with_retry(call):
    last_error = None

    for attempt in range(MAX_RETRIES_PER_MODEL):
        try:
            return call()
        except Exception as exc:
            last_error = exc

            if not _is_transient_unavailable(exc):
                raise

            if attempt < MAX_RETRIES_PER_MODEL - 1:
                time.sleep(RETRY_DELAYS_SECONDS[attempt])

    raise last_error


def _generate_with_fallback(prompt: str, config):
    client = get_client()
    errors = []

    for model in _candidate_models():
        try:
            response = _call_with_retry(
                lambda: client.models.generate_content(
                    model=model,
                    contents=prompt,
                    config=config,
                )
            )
            return response, model
        except Exception as exc:
            errors.append(f"{model}: {exc}")

            # Move to the next model when the current one is unsupported or
            # temporarily overloaded. Preserve other errors immediately.
            if not (_is_model_not_found(exc) or _is_transient_unavailable(exc)):
                raise

    raise RuntimeError(
        "All configured Gemini models were unavailable after retries. "
        "Please wait a moment and try again. "
        f"Model errors: {' | '.join(errors)}"
    )


def generate_text(prompt: str, *, system_instruction: str | None = None) -> str:
    try:
        response, _model = _generate_with_fallback(
            prompt, _generation_config(system_instruction=system_instruction)
        )
    except Exception as exc:
        raise RuntimeError(_friendly_gemini_error(exc)) from exc

    text = getattr(response, "text", None)
    if not text:
        raise RuntimeError("Gemini returned an empty response. Please try again.")
    return text.strip()


def _structured_config(settings, schema):
    from google.genai import types

    kwargs = {
        "max_output_tokens": settings.max_output_tokens,
        "response_mime_type": "application/json",
        "response_schema": schema,
    }

    if settings.gemini_model.strip().startswith("gemini-3"):
        kwargs["thinking_config"] = types.ThinkingConfig(thinking_level="low")
    else:
        kwargs["temperature"] = settings.temperature

    return types.GenerateContentConfig(**kwargs)


def generate_structured(prompt: str, schema: Type[T]) -> T:
    settings = get_settings()
    client = get_client()
    errors = []

    for model in _candidate_models():
        try:
            response = _call_with_retry(
                lambda: client.models.generate_content(
                    model=model,
                    contents=prompt,
                    config=_structured_config(settings, schema),
                )
            )

            parsed = getattr(response, "parsed", None)
            if isinstance(parsed, schema):
                return parsed
            if parsed is not None:
                return schema.model_validate(parsed)

            text = getattr(response, "text", None)
            if not text:
                raise RuntimeError(
                    "Gemini returned no structured output. Please try again."
                )
            return schema.model_validate_json(text)

        except Exception as exc:
            errors.append(f"{model}: {exc}")

            if _is_model_not_found(exc) or _is_transient_unavailable(exc):
                continue

            raise RuntimeError(_friendly_gemini_error(exc)) from exc

    raise RuntimeError(
        "All configured Gemini models were unavailable after retries. "
        "Please wait a moment and try again. "
        f"Model errors: {' | '.join(errors)}"
    )


def _friendly_gemini_error(exc: Exception) -> str:
    message = str(exc)
    lower = message.lower()

    if "api key" in lower or "unauthenticated" in lower or "permission" in lower:
        return (
            "Gemini rejected the API key. Check GEMINI_API_KEY in .env "
            "and make sure the key is active."
        )
    if "not found" in lower or "404" in lower or "is not supported" in lower:
        return (
            "The configured Gemini model is not available. EduGenie tried "
            "the supported fallback models, but none were accepted."
        )
    if "quota" in lower or "resource exhausted" in lower or "429" in lower:
        return (
            "Gemini API quota or rate limit was reached. Please wait a moment "
            "and try again."
        )
    if "503" in lower or "unavailable" in lower or "high demand" in lower:
        return (
            "Gemini is temporarily busy or unavailable. EduGenie retried the "
            "request and tried fallback models. Please try again in a moment."
        )
    if "timeout" in lower or "timed out" in lower:
        return "The Gemini request timed out. Please try again."
    if "safety" in lower or "blocked" in lower:
        return (
            "Gemini blocked the request under its safety rules. "
            "Try a different educational prompt."
        )

    return f"Gemini request failed: {message}"
