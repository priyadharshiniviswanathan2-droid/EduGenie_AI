from gemini_client import generate_text


def answer_question(question: str) -> str:
    prompt = f"""
Answer the student's question accurately and concisely.

Question:
{question}

Requirements:
- Explain the answer at an appropriate educational level.
- Start with the direct answer.
- Use short sections, bullets, or examples when useful.
- If the question is ambiguous, state the assumption you made.
- Do not invent citations, sources, or facts.
"""
    return generate_text(
        prompt,
        system_instruction=(
            "You are EduGenie, a patient educational assistant. "
            "Prioritize clarity, correctness, and useful explanations."
        ),
    )
