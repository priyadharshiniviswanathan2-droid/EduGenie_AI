from typing import List

from pydantic import BaseModel, Field, field_validator

from gemini_client import generate_structured


class QuizQuestion(BaseModel):
    question: str = Field(min_length=1)
    options: List[str] = Field(min_length=4, max_length=4)
    correct_answer: str = Field(min_length=1)
    explanation: str = Field(min_length=1)

    @field_validator("options")
    @classmethod
    def options_must_be_unique(cls, value):
        if len(set(value)) != len(value):
            raise ValueError("Quiz options must be unique.")
        return value

    @field_validator("correct_answer")
    @classmethod
    def answer_must_be_an_option(cls, value, info):
        options = info.data.get("options", [])
        if options and value not in options:
            raise ValueError("correct_answer must exactly match one option.")
        return value


class QuizResponse(BaseModel):
    questions: List[QuizQuestion] = Field(min_length=3, max_length=3)


def generate_quiz(passage: str) -> QuizResponse:
    prompt = f"""
Create exactly three multiple-choice questions from the educational input below.

INPUT:
{passage}

Rules:
- Exactly 3 questions.
- Exactly 4 unique options per question.
- Only one option is correct.
- correct_answer must exactly equal the correct option text.
- Include a brief explanation for each answer.
- Questions must be answerable from the input when the input contains enough information.
- If the input is a broad topic rather than a passage, test foundational knowledge of that topic.
- Avoid trick questions and duplicate questions.
"""
    return generate_structured(prompt, QuizResponse)
